<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Fetch available table names dynamically
$tables = [];
$result = mysqli_query($conn, "SHOW TABLES");
while ($row = mysqli_fetch_row($result)) {
    $tables[] = $row[0];
}

// Handle table selection form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['table_name'])) {
    $selected_table = $_POST['table_name'];
    header("Location: admin_view_table.php?table=$selected_table");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <form method="POST" action="admin_dashboard.php">
        <label for="table_name">Select Table:</label>
        <select id="table_name" name="table_name" required>
            <?php foreach ($tables as $table): ?>
                <option value="<?php echo $table; ?>"><?php echo $table; ?></option>
            <?php endforeach; ?>
        </select>
        <br>
        <button type="submit">View Data</button>
    </form>
    <br>
    <a href="admin_logout.php">Logout</a>
    
    <link rel="stylesheet" href="admin/admin_dashboard.css">

</body>
</html>
