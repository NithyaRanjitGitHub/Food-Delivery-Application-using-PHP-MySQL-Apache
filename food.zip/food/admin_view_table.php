<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Get selected table name
if (!isset($_GET['table'])) {
    echo "<p>No table selected. <a href='admin_dashboard.php'>Go back</a></p>";
    exit();
}

$table_name = $_GET['table'];

// Fetch data from the selected table
$sql = "SELECT * FROM $table_name";
$result = mysqli_query($conn, $sql);

// Check for errors
if (!$result) {
    echo "Error fetching data: " . mysqli_error($conn);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Table: <?php echo htmlspecialchars($table_name); ?></title>
</head>
<body>
    <h1>Table: <?php echo htmlspecialchars($table_name); ?></h1>
    <table border="1">
        <thead>
            <tr>
                <?php
                $fields = mysqli_fetch_fields($result);
                foreach ($fields as $field) {
                    echo "<th>" . htmlspecialchars($field->name) . "</th>";
                }
                ?>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <?php foreach ($row as $value): ?>
                        <td><?php echo htmlspecialchars($value); ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <br>
    <a href="admin_dashboard.php">Back to Dashboard</a>
    <link rel="stylesheet" href="admin/admin_view_table.css">

</body>
</html>
