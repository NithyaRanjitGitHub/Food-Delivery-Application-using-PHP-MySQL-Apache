<?php
include 'session_handler.php';
?>
<?php session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$order_sql = "SELECT id FROM orders WHERE user_id = $user_id AND status = 'Pending'";
$order_result = mysqli_query($conn, $order_sql);

if (mysqli_num_rows($order_result) == 0) {
    $create_order_sql = "INSERT INTO orders (user_id, status) VALUES ($user_id, 'Pending')";
    mysqli_query($conn, $create_order_sql);
    $order_id = mysqli_insert_id($conn); // Get the new order's ID
} else {
    $order = mysqli_fetch_assoc($order_result);
    $order_id = $order['id'];
}

// Add an item to the cart
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $dish_id = $_POST['dish_id'];
    $quantity = $_POST['quantity'];
    
    // Check if the item is already in the cart
    $check_item_sql = "SELECT * FROM order_items WHERE order_id = $order_id AND dish_id = $dish_id";
    $check_item_result = mysqli_query($conn, $check_item_sql);
    
    if (mysqli_num_rows($check_item_result) > 0) {
        // Item already exists in the cart, update quantity
        $update_quantity_sql = "UPDATE order_items SET quantity = quantity + $quantity WHERE order_id = $order_id AND dish_id = $dish_id";
        mysqli_query($conn, $update_quantity_sql);
    } else {
        // Add new item to the cart
        $add_item_sql = "INSERT INTO order_items (order_id, dish_id, quantity) VALUES ($order_id, $dish_id, $quantity)";
        mysqli_query($conn, $add_item_sql);
    }
}

// Fetch cart items
$sql = "SELECT oi.id AS order_item_id, oi.quantity, d.name AS dish_name, d.price 
        FROM order_items oi
        INNER JOIN dishes d ON oi.dish_id = d.id
        WHERE oi.order_id = $order_id";

$result = mysqli_query($conn, $sql);

if (!$result) {
    echo "Error fetching cart items: " . mysqli_error($conn);
    exit();
}

// Handle cart item removal
if (isset($_GET['remove_item'])) {
    $order_item_id = $_GET['remove_item'];
    $remove_item_sql = "DELETE FROM order_items WHERE id = $order_item_id";
    mysqli_query($conn, $remove_item_sql);
    header("Location: your_order.php"); // Reload page after removal
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
</head>
<body>
    <h1>Your Cart</h1>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>Dish</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Remove</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            $grandTotal = 0;
            while ($row = mysqli_fetch_assoc($result)): 
                $totalPrice = $row['price'] * $row['quantity'];
                $grandTotal += $totalPrice;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['dish_name']); ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                    <td><?php echo $totalPrice; ?></td>
                    <td><a href="your_order.php?remove_item=<?php echo $row['order_item_id']; ?>">Remove</a></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4" style="text-align: right;"><strong>Grand Total:</strong></td>
                    <td><strong><?php echo $grandTotal; ?></strong></td>
                </tr>
            </tfoot>
        </table>

    <a href="checkout.php"><button>Proceed to Checkout</button></a>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>

    <h2>Add Items to Cart</h2>
    <form method="POST" action="your_order.php">
        <label for="dish_id">Dish:</label>
        <select name="dish_id" id="dish_id">
            <?php
            $dishes_sql = "SELECT * FROM dishes";
            $dishes_result = mysqli_query($conn, $dishes_sql);
            while ($dish = mysqli_fetch_assoc($dishes_result)) {
                echo "<option value='" . $dish['id'] . "'>" . htmlspecialchars($dish['name']) . "</option>";
            }
            ?>
        </select><br>

        <label for="quantity">Quantity:</label>
        <input type="number" name="quantity" id="quantity" value="1" min="1"><br>

        <button type="submit" name="add_to_cart">Add to Cart</button>
    </form>
    <link rel="stylesheet" href="css/your_order.css">

</body>
</html>



