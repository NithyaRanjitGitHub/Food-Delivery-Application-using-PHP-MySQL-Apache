<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch the active pending order
$order_sql = "SELECT id, total_amount FROM orders WHERE user_id = $user_id AND status = 'Pending'";
$order_result = mysqli_query($conn, $order_sql);

if (mysqli_num_rows($order_result) == 0) {
    echo "No pending orders found.";
    exit();
} else {
    $order = mysqli_fetch_assoc($order_result);
    $order_id = $order['id'];
    $total_amount = $order['total_amount'];
}

// Fetch the items in the cart for the user to review
$sql = "SELECT oi.id AS order_item_id, oi.quantity, d.name AS dish_name, d.price 
        FROM order_items oi
        INNER JOIN dishes d ON oi.dish_id = d.id
        WHERE oi.order_id = $order_id";

$result = mysqli_query($conn, $sql);

if (!$result) {
    echo "Error fetching order details: " . mysqli_error($conn);
    exit();
}

// Handle the order confirmation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_order'])) {
    // Update the order status to 'Confirmed'
    $confirm_order_sql = "UPDATE orders SET status = 'Confirmed' WHERE id = $order_id";
    if (mysqli_query($conn, $confirm_order_sql)) {
        // Redirect to a success page or payment gateway
        header("Location: order_sucess.php");
        exit();
    } else {
        echo "Error confirming order: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Order</title>
</head>
<body>
    <h1>Confirm Your Order</h1>
    <?php if (mysqli_num_rows($result) > 0): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>Dish</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            $grandTotal = 0;
            while ($row = mysqli_fetch_assoc($result)): 
                $totalPrice = $row['price'] * $row['quantity'];
                $grandTotal += $totalPrice;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['dish_name']); ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                    <td><?php echo $totalPrice; ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" style="text-align: right;"><strong>Grand Total:</strong></td>
                    <td><strong><?php echo $grandTotal; ?></strong></td>
                </tr>
            </tfoot>
        </table>
        
        <form method="POST" action="confirm_order.php">
            <input type="submit" name="confirm_order" value="Confirm Order">
        </form>
    <?php else: ?>
        <p>Your cart is empty. <a href="restaurants.php">Add items to your cart.</a></p>
    <?php endif; ?>
</body>
<link rel="stylesheet" href="css/confirm_order.css">

</html>
