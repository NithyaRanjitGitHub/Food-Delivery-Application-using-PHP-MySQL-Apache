CREATE DATABASE food_delivery;
USE food_delivery;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE restaurants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(255),
    description TEXT
);

CREATE TABLE dishes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2),
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    restaurant_id INT,
    total_amount DECIMAL(10, 2) DEFAULT 0,
    status VARCHAR(20) DEFAULT 'Pending',
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    dish_id INT,
    quantity INT DEFAULT 1,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (dish_id) REFERENCES dishes(id)
);

-- Insert a sample user
INSERT INTO users (username, email, password) VALUES 
('test_user', 'test@example.com', PASSWORD('password123'));


-- Sample restaurants
INSERT INTO restaurants (name, location, description) VALUES
('Pizza Palace', 'Downtown', 'Best pizzas in town with a variety of toppings.'),
('Sushi World', 'City Center', 'Fresh sushi and Japanese cuisine.');

-- Sample dishes for Pizza Palace
INSERT INTO dishes (restaurant_id, name, description, price) VALUES
(1, 'Margherita Pizza', 'Classic pizza with tomato, mozzarella, and basil.', 8.99),
(1, 'Pepperoni Pizza', 'Topped with pepperoni and cheese.', 9.99),
(1, 'Veggie Pizza', 'Loaded with fresh vegetables.', 10.99);

-- Sample dishes for Sushi World
INSERT INTO dishes (restaurant_id, name, description, price) VALUES
(2, 'Salmon Nigiri', 'Fresh salmon over vinegared rice.', 5.99),
(2, 'California Roll', 'Crab, avocado, cucumber.', 7.99),
(2, 'Spicy Tuna Roll', 'Spicy tuna with scallions.', 8.49);
