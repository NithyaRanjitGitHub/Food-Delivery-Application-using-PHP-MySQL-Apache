<?php
include 'session_handler.php';
?>
<?php
// Start session and check if the user is logged in

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
include 'welcome.php';  // This file ensures the user is logged in

// Now you can use $user_id and $user_email in this page
echo "Welcome, $user_email!"
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Restaurants</title>
<br><!-- comment -->
    <link rel="stylesheet" href="css/restaurants.css">
</head>
<body>
    <h1>Welcome to the Restaurant Page</h1>

    <!-- Logout Button -->
    <form action="logout.php" method="POST">
        <button type="submit">Logout</button>
    </form>
   <div class="restaurant-container">
    <?php
    include 'config.php';
 

    // Fetch all restaurants from the database
    $result = mysqli_query($conn, "SELECT * FROM restaurants");

    echo "<h1>Restaurants</h1><br>";


    while ($row = mysqli_fetch_assoc($result)) {
        // Generate the image path
        $restaurant_name = strtolower(str_replace(" ", "_", $row['name']));
 // Determine the image path based on the restaurant name
        if ($restaurant_name == "pizza_palace") {
            $image_path = "pizzashop.jfif";
        } elseif ($restaurant_name == "sushi_world") {
            $image_path = "sushi.jfif";
        } else {
            $image_path = "images/restaurant_default.jpg"; // Default image for other restaurants
        }

        // Use a placeholder if the image doesn't exist
        if (!file_exists($image_path)) {
            $image_path = "images/default_restaurant.jpg"; // Fallback image
        }

        // Display restaurant details
        echo "<div style='margin-bottom: 20px;'>";
        echo "<img src='$image_path' alt='" . htmlspecialchars($row['name']) . "' style='width:200px;height:auto;border-radius:8px;'>";
        echo "<h2><a href='dishes.php?restaurant_id=" . $row['id'] . "'>" . htmlspecialchars($row['name']) . "</a></h2>";
        echo "<p>" . htmlspecialchars($row['description']) . "</p>";
        echo "</div>";
    }
    ?>
    
    
    
    
    //<?php
//    while ($row = mysqli_fetch_assoc($result)) {
//        $restaurant_name = strtolower(str_replace(" ", "_", $row['name']));
//        if ($restaurant_name == "pizza_palace") {
//            $image_path = "pizzashop.jfif";
//        } elseif ($restaurant_name == "sushi_world") {
//            $image_path = "sushi.jfif";
//        } else {
//            $image_path = "images/restaurant_default.jpg";
//        }
//        if (!file_exists($image_path)) {
//            $image_path = "images/default_restaurant.jpg";
//        }
//        echo "<div class='restaurant-card'>";
//        echo "<img src='$image_path' alt='" . htmlspecialchars($row['name']) . "'>";
//        echo "<h2><a href='dishes.php?restaurant_id=" . $row['id'] . "'>" . htmlspecialchars($row['name']) . "</a></h2>";
//        echo "<p>" . htmlspecialchars($row['description']) . "</p>";
//        echo "</div>";
//    }
//    ?>
</div>
   
    
</body>
</html>

