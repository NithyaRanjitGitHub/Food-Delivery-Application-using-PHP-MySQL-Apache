
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <header>
        <h1>Login to Food Delivery</h1>
    </header>
    <div class="container">
        <form method="POST" action="">
            <label>Email:</label>
            <input type="email" name="email" required><br>
            <label>Password:</label>
            <input type="password" name="password" required><br>
            <button type="submit">Login</button>
        </form>
        <p>Don't have an account? <a href="register.php">Sign up here</a></p>
    </div>
</body>
</html>

<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Query to fetch user data by email
    $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // Check if the stored password is hashed or plain text
        $stored_password = $user['password'];

        if (
            // Verify hashed password
            (password_verify($password, $stored_password)) ||
            // Compare plain text password (fallback for insecure storage)
            ($password === $stored_password)
        ) {
            // Log in the user
            $_SESSION['user_id'] = $user['id'];

            // Set cookies for user ID and email (expire in 7 days)
            setcookie("user_id", $user['id'], time() + (7 * 24 * 60 * 60), "/");
            setcookie("user_email", $user['email'], time() + (7 * 24 * 60 * 60), "/");

            header("Location: restaurants.php");
            exit;
        } else {
            echo "<p style='color:red;'>Invalid credentials (Password mismatch).</p>";
        }
    } else {
        echo "<p style='color:red;'>No user found with that email.</p>";
    }
}
?>

<?php
session_start();
include 'config.php';

// Handle the login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if username and password are valid (this is just a sample, replace with your logic)
    $stored_username = "user"; // This should be from the database
    $stored_password = "password"; // This should be from the database

    if ($username === $stored_username && $password === $stored_password) {
        // Set a cookie for 30 days (username stored in cookie)
        setcookie("username", $username, time() + (30 * 24 * 60 * 60), "/"); // 30 days expiration

        $_SESSION['user_logged_in'] = true;
        header("Location: welcome.php"); // Redirect to a dashboard or home page
        exit();
    } else {
        echo "Invalid credentials.";
    }
}
?>

