<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Sign Up for Food Delivery</h1>
    </header>
    <div class="container">
        <form method="POST" action="">
            <label>Name:</label>
            <input type="text" name="name" required><br>
            <label>Phone Number:</label>
            <input type="text" name="phone" required><br>
            <label>Email:</label>
            <input type="email" name="email" required><br>
            <label>Password:</label>
            <input type="password" name="password" required><br>
            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>
<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']); // Do not hash the password

    // Check if the user already exists
    $check_user = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

    if ($check_user && mysqli_num_rows($check_user) > 0) {
        echo "<p style='color:red; text-align: center;'>Email already registered. <a href='login.php'>Login here</a></p>";
    } else {
        // Insert user into the database
        $insert_user = mysqli_query($conn, "INSERT INTO users (name, phone, email, password) VALUES ('$name', '$phone', '$email', '$password')");
        
        if ($insert_user) {
            echo "<p style='color:green; text-align: center;'>Registration successful. <a href='restaurants.php'>Login here</a></p>";
        } else {
            echo "<p style='color:red; text-align: center;'>Error registering user. Please try again.</p>";
        }
    }
}
?>
